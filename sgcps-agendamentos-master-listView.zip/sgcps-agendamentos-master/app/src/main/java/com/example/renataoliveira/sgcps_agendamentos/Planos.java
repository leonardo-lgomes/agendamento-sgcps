package com.example.renataoliveira.sgcps_agendamentos;

import java.util.ArrayList;
import java.util.List;

public class Planos {

    String nome;
    Integer imagem;

    public static List<Planos> getPlanos(){
        List<Planos> planos = new ArrayList<Planos>();
        planos.add(new Planos ("Intermedica", R.drawable.Intermedica));
        planos.add(new Planos ("Bradesco", R.drawable.Bradesco));
        planos.add(new Planos ("Medtour", R.drawable.Medtour));
        planos.add(new Planos ("Ameplan", R.drawable.Ameplan));

        return planos;
    }


}
