package com.example.renataoliveira.sgcps_agendamentos;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import javax.naming.Context;
import javax.swing.text.View;

//classe criada para a lista view

public class SimplesAdapter extends BaseAdapter {

    Context context;

    public SimplesAdapter (Context context) {
        this.context = context;
    }

    String[] listaPlanos =
            new String [] {"UNIMED", "MED-TOUR","BRADESCO","AMEPLAN","INTERMEDICA","OUTROS"};

    @Override
    public int getCount() {
        return listaPlanos.length;
    }
    @Override
    public Object getItem (int posicao) {
        return listaPlanos[posicao];
    }

    @Override
    public long getItemId(int posicao) {
        return posicao;
    }

    @Override
    public android.view.View getView(int posicao, android.view.View view, ViewGroup viewGroup) {
        String planos = listaPlanos[posicao];

        View viewText = LayoutInflater.from(context).inflate(R.layout.tela_inicial_itens, viewGroup, false);
        TextView t = (TextView)viewText.findViewById(R.id.textItemList);
        t.setText(planos);
        return viewText;
    }
        //calcular tamanho em tela de acordo com a densidade
        float dip = 50;
        float densidade =
                context.getResources().getDisplayMetrics().density;
        int px = (int) (dip * densidade + 0.5f);
        t.setHeight(px);
        t.setText(planos);

        return t;
    }

    @Override
    public View getView (int i, View view, ViewGroup viewGroup) {
        return null;
    }

}
