package com.example.renataoliveira.sgcps_agendamentos;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import javax.naming.Context;

public class PlanosAdapter extends BaseAdapter {

    private final Context context;
    private final List <Planos> listaPlanos;

    public PlanosAdapter(Context context,
                         List<Planos> ListaCervejas){

        this.context = context;
        this.listaPlanos = listaPlanos;
    }

    @Override
    public int getCount(){
        return listaPlanos !=null? listaPlanos.size () : 0;

    }

    @Override
    public Object getItem (int posicao){
        return listaPlanos.get(posicao);

    }

    @Override
    public long getItemId(int posicao){
        return posicao;

    }

    @Override
    public View getView (int posicao, View view, ViewGroup viewGroup){
       //infla a View
       View viewText = LayoutInflater.from((android.content.Context) context).inflate(R.layout.tela_inicial_itens, viewGroup, false);
       //Procura elementos da tela para atualizar
        TextView t = (TextView) viewText.findViewById((R.id.textItemList);
        //atualiza valores da view
        Planos planos = listaPlanos.get(posicao);
        t.setText(planos.nome);
        img.setImageResource(corretora.imagem);
        return  viewText;
    }
}
